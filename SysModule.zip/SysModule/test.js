function deleteRow(el) {
    if (!confirm("Are you sure you want to delete?")) return;

    var tbl = el.parentNode.parentNode.parentNode;
    var row = el.parentNode.parentNode.rowIndex;

    tbl.deleteRow(row - 1);

}

$(document).ready(function() {
    //To hide the table

    $(".showDataTopTable").click(function() {
        $(".table_button").hide()
        $(".table_top").show("fast")
        $(".table_button_pro").hide()
        $(".table_button_set_pro").hide()


    });
    $(".showDataButtonTable").click(function() {
        $(".table_top").hide()
        $(".table_button").show("fast")
        $(".table_top_pro").hide()

    });

    $(".showAddDataTopProperties").click(function() {
        $(".table_top_pro").show("fast")
    });

    $(".showAddDataButtonProperties").click(function() {
        $(".table_button_pro").show("fast")
    });

    $(".showAddDataSetProperties").click(function() {
        $(".table_button_set_pro").show("fast")
    });

    $('textarea.autogrow').each(function() {
        $(this).css('overflow-y', 'hidden');
    }).on('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });






    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function(form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })()
});

var textarea = document.querySelector('textarea');

textarea.addEventListener('keydown', autosize);

function autosize() {
    var el = this;
    setTimeout(function() {
        el.style.cssText = 'height:auto; padding:0';
        // for box-sizing other than "content-box" use:
        // el.style.cssText = '-moz-box-sizing:content-box';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
    }, 0);
}